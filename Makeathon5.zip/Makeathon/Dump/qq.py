import pytesseract
from PIL import Image

# Open the image file using Pillow
with Image.open('test.png') as img:
    # Convert the image to grayscale
    img = img.convert('L')
    # Use Pytesseract to extract text from the image
    text = pytesseract.image_to_string(img)

# Print the extracted text
print(text)