from Levenshtein import distance

print(distance("tewpvn","tewpnv"))