
from flask import Flask, jsonify, request
from module import search,create,LCS
from Levenshtein import distance
import json, os



app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({"0":"0"})

@app.route('/search',methods=['GET'])
def search_a():
    DAC = request.args.get('DAC')
    name = request.args.get('name')
    if(len(DAC)==0 and len(name)==0):
        return jsonify({"0":"Error"})
    try:
        with open("Backend\countries.json", 'r') as r:
            
            d=json.load(r);

        try:
            country=d[DAC[:2]]["0"]
            state_bits=int(d[DAC[:2]]["1"])
        except KeyError:
            print("Key {} not found!".format(DAC[:2]))

        n=7-state_bits

        dat = search(country=country,state=DAC[2:2+state_bits],DAC=DAC[state_bits+2:])

        if(dat['Owner'].lower()==name.lower()):
            return jsonify(dat);
        else:
            return jsonify("Access Denied")

    except Exception as err:
        print(err)

@app.route('/create',methods=['GET','POST'])
def create_a():
    #take fields
    name=request.args.get('name').capitalize()
    Id_no = request.args.get('Identification')
    #gender = request.args.get('gender')
    address = request.args.get('address')
    #email = request.args.get('email')

    #file we will be using from image processor
    os.system("python D:\Random\Makeathon\ImageProcess\gfg.py");
    path = r'D:\Random\Makeathon\recognized.txt'

    with open(path) as f:
        lines = f.readlines()

    extract=dict(); flag=1;
    for i in lines:
        if "name" in i.lower():
            extract[0]=i.lower()
        if "address" in i.lower():
            extract[1]=i.lower()
        if Id_no in i:
            flag=0;
    if(flag==1):
        #implement model for closeby answer
        pass
    else:
        if(name.lower() in extract[0] or LCS(name.lower(),extract[0])/len(extract[0])>0.6):
            if(distance(address, extract[1])):

                pass
        else:
            flag=1;

if __name__ == "__main__":
    app.run(debug="True",port=5000)