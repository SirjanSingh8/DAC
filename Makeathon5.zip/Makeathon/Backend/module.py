import json,os,logging
logging.basicConfig(filename='app.log', filemode='a',format='%(asctime)s - %(message)s', level=logging.INFO)


def search(country: str="",state: str="", DAC: str=""):
    l=os.listdir(r"Backend\Data");
    try:
        k=str(country)+".json"
        l.index(k)
        k="Backend\Data\\"+k

        #File located! search
        with open(k, 'r') as r:
            d=json.load(r);
        
        #d contains state and file for the state
        alpha = "Backend\Data\SubData-AllInfo\\"+str(d[state]["1"])+".json"

        #alpha has file path and DAC has key
        with open(alpha, 'r') as r:
            d1=json.load(r);
        
        d1=d1[DAC]
        logging.info("INFO: DAC ID {} was accessed!!".format(country+state+DAC))

        return d1


    except ValueError:
        #error file not found -> create one!
        logging.error("ERROR: File {}.json was not found!".format(country))
        return -1;
    except KeyError:
        logging.error("ERROR: Record for {} not found".format(country+state+DAC))
        return -2;
    except FileNotFoundError:
        return -3;


def chksum(k: str,country: str, stat: str, state: str):
    #return new file number and update 'Cur_State' in countries.json
    #k has data like '1D34X6C8' and we need to give the next one in serial order
    nos=[str(x) for x in range(0,10)]
    kk=[]
    for i in k:
        if i in nos:
            kk.append(int(i))
        else:
            kk.append(ord(i)-55)
    i=7
    while(i!=0):
        if kk[i] < 35:
            kk[i]+=1;
            break;
        else:
            kk[i]=0;
            i-=1;
        pass
    kkk=""
    for i in kk:
        if int(i)<10:
            kkk+=str(i)
        else:
            kkk+=chr(i+55)
    with open("Backend\countries.json",'r+') as file:
        file_data = json.load(file)
        file_data["Cur_State"]=kkk
        file.seek(0)
        json.dump(file_data, file, indent = 4)
    kappa="Backend\Data\\"+country+".json"
    if len(state)==2:
        #state0
        if(47<ord(state[1]) and ord(state[1])<58):
            state_no=ord(state[1])-48
        else:
            state_no=ord(state[1])-55
        #state1
        if(47<ord(state[0]) and ord(state[0])<58):
            state_no+=100*(ord(state[0])-48)
        else:
            state_no+=100*(ord(state[0])-55)
        pass
    else:
        if(47<ord(state) and ord(state)<58):
            state_no=ord(state)-48
        else:
            state_no=ord(state)-55
    with open(kappa,'r+') as file:
        file_data = json.load(file)
        file_data[str(state_no)]={"0":stat,"1":kkk}
        file.seek(0)
        json.dump(file_data, file, indent = 4)
    return kkk;


def create(country: str,stat: str, state: str, DAC: str,dat: dict):
    l=os.listdir(r"Backend\Data");
    try:
        k=country+".json"
        l.index(k)

        #file found
        k="Backend\Data\\"+k
        #File located! search
        dd={}
        with open(k, 'r') as r:
            dd=json.load(r)
        
        try:
            alpha = "Backend\Data\SubData-AllInfo\\"+str(dd[state]["1"])+".json"
            with open(alpha,'r+') as file:
                file_data = json.load(file)
                try:
                    _=file_data[DAC]
                    logging.error("ERROR: Duplicate for {} exists!".format(country+state+DAC))
                    return -99
                except KeyError:
                    file_data[DAC]=dat
                finally:
                    file.seek(0)
                    json.dump(file_data, file, indent = 4)
            return 0;
        except KeyError as err:
            #create file for state and update in country table
            with open(r"Backend\countries.json", "r") as r:
                dk = json.load(r)
            k="Backend\Data\SubData-AllInfo\\"+chksum(dk['Cur_State'],country,stat,state)+".json"
            d={}
            d[DAC]=dat
            with open(k,'w') as r:
                d=json.dumps(r)            


    except ValueError as err:
        #file not found
        logging.info("INFO: File {}.json was created!".format(country))
        k="Backend\Data\\"+country+".json"
        with open(k, 'w') as r:
            r.dump(json.stringify({}))
        #copy from line 50 till above exception handle
        #File located! search
        #create file for state and update in country table
        with open(r"Backend\countries.json", 'r') as r:
            dk = json.load(r)
        
        k="Backend\Data\SubData-AllInfo\\"+chksum(dk['Cur_State'],country,stat,state)+".json"
        d={}
        d[DAC]=dat
        with open(k,'w') as r:
            json.dumps(d) 


def LCS(A, B):
	n = len(A)
	m = len(B)

	# Auxiliary dp[][] array
	dp = [[0 for i in range(n + 1)] for i in range(m + 1)]

	# Updating the dp[][] table
	# in Bottom Up approach
	for i in range(n - 1, -1, -1):
		for j in range(m - 1, -1, -1):

			# If A[i] is equal to B[i]
			# then dp[j][i] = dp[j + 1][i + 1] + 1
			if A[i] == B[j]:
				dp[i][j] = dp[i + 1][j + 1] + 1
	maxm = 0

	# Find maximum of all the values
	# in dp[][] array to get the
	# maximum length
	for i in dp:
		for j in i:

			# Update the length
			maxm = max(maxm, j)

	# Return the maximum length
	return maxm
